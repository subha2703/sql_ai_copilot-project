# SQL AI Copilot Project (Offline)

## Description:
A local AI copilot that takes natural language and converts it to SQL, runs it on a local SQLite database using a lightweight model (like Phi-2 in GGUF format).

## Files:
- create_table.py: Creates a sample sales database
- sql_copilot_local.py: Loads LLM and queries the DB
- models/: Place your GGUF file here (e.g., phi-2.Q4_K_M.gguf)

## Requirements:
- Python 3.10+
- pip install langchain llama-cpp-python

Run:
python create_table.py
python sql_copilot_local.py
