import sqlite3

conn = sqlite3.connect("sample.db")
cursor = conn.cursor()

cursor.execute('''
CREATE TABLE IF NOT EXISTS sales (
    id INTEGER PRIMARY KEY,
    name TEXT,
    amount INTEGER,
    year INTEGER
)
''')

sample_data = [
    ("Alice", 200, 2023),
    ("Bob", 450, 2023),
    ("Charlie", 300, 2022)
]

cursor.executemany("INSERT INTO sales (name, amount, year) VALUES (?, ?, ?)", sample_data)
conn.commit()
conn.close()

print("Database and table created with sample data.")
