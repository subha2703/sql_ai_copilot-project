from langchain.llms import LlamaCpp
import sqlite3

# Load model
llm = LlamaCpp(
    model_path="models/phi-2.Q4_K_M.gguf", 
    temperature=0.7,
    max_tokens=256,
    n_ctx=2048,
    verbose=True
)

# Ask model
question = "Who spent the most in 2023?"
prompt = f"Convert this question to SQL: {question}"
sql_query = llm(prompt)

print(f"Generated SQL Query: {sql_query}")

# Execute SQL on SQLite
conn = sqlite3.connect("sample.db")
cursor = conn.cursor()
try:
    cursor.execute(sql_query)
    result = cursor.fetchall()
    print("Result:", result)
except Exception as e:
    print("SQL Error:", e)
conn.close()
